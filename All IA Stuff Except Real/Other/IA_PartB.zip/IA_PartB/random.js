    
    
    
    
        <div class="row">
        <div class="col s12 m7">
            <div class="card">
            <div class="card medium blue darken-3">
            </div>
                <div class="card-content white-text">
                <span class="card-title">Card Display of Images in Database</span>
                <img style="max-width: 65%; max-height: 65%;" src="${imageURL}"/>
                <p>Image Displayed Above</p>
            </div>
            <div class="card-action">
            <a href="#">This is a link</a>
            </div>
        </div>
    </div>
    </div>
    ;

    return card;
}



<div class="col s6 m6 l4">
<div class="divider"></div>
<div class="section">
<div class="card medium blue darken-3">
    <div class="card-content white-text">
        <span class="card-title">Card Display of Images in Database</span>
        <img style="max-width: 65%; max-height: 65%;" src="${imageURL}"/>
        <p>Image Displayed Above</p>
    </div>
    <div class="card-action">
        <a href="#">This is a link</a>
        <a href="#">This is a link</a>
    </div>
</div>
</div>
`;

return card;
}


function createImageCard(imageURL) {
    var card = `
        <div class="col s12 m6 l4">
        <div class="card medium blue-grey darken-1">
            <div class="card-content white-text">
                <span class="card-title">Card Display of Images in Database</span>
                <img style="max-width: 45%; max-height: 45%;" src="${imageURL}"/>
                <p>Image Displayed Above</p>
            </div>
            <div class="card-action">
                <a href="#">This is a link</a>
                <a href="#">This is a link</a>
            </div>
        </div>
    </div>
    `;

    return card;
}

<div class="row">
        <div class="col s12 m7">
            <div class="card">
            <div class="card medium blue darken-3">
            </div>
                <div class="card-content white-text">
                <span class="card-title">Card Display of Images in Database</span>
                <img style="max-width: 65%; max-height: 65%;" src="${imageURL}"/>
                <p>Image Displayed Above</p>
            </div>
            <div class="card-action">
            <a href="#">This is a link</a>
            </div>
            </div>
            </div>
        </div>
        </div>
        ;

    return card;

}     


<div class="row">
    <div class="col s12 m7">
      <div class="card">
        <div class="card-image">
        <img style="max-width: 65%; max-height: 65%;" src="${imageURL}"/>
          <span class="card-title">Card Title</span>
        </div>
        <div class="card-content">
          <p>I am a very simple card. I am good at containing small bits of information.
          I am convenient because I require little markup to use effectively.</p>
        </div>
        <div class="card-action">
          <a href="#">This is a link</a>
        </div>
      </div>
    </div>
  </div>